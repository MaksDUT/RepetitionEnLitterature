## Répétition en littérature

Répétition en littérature est un projet scolaire conçu par des étudiants de Marne la Vallée. 

Le projet à pour but de retrouver dans un text des répétitions qui creer chez le lecteur un sentiment de familiarité. 

l'etude se fait sur le corpus d'Emile Zola *Les Rougon-Macquart*

Deux programmes ont été conçu, deux magnières différentes de répondre au sujet.
### Algorithme par Mot Rare 

### Algorithme par Arbre des suffix  

Pour plus d'informations sur les Algorithmes, des README existe.

